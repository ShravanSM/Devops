const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const FLASK_API_URL = process.env.FLASK_API_URL || "http://127.0.0.1:5000";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/health", (req, res) => {
  res.json({ status: "healthy", service: "express-frontend" });
});

app.get("/api/backend-status", async (req, res) => {
  try {
    const response = await fetch(`${FLASK_API_URL}/api/status`);
    if (!response.ok) {
      return res.status(502).json({ status: "DOWN", message: "Flask backend returned an error" });
    }
    res.json(await response.json());
  } catch {
    res.status(502).json({ status: "DOWN", message: "Flask backend is unavailable" });
  }
});

if (require.main === module) {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DevOps Dashboard running at http://localhost:${PORT}`);
    console.log(`Flask API: ${FLASK_API_URL}`);
  });
}

module.exports = app;
