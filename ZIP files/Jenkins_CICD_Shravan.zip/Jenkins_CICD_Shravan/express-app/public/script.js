const frontendBadge = document.getElementById("frontend-badge");
const backendBadge = document.getElementById("backend-badge");
const overallStatus = document.getElementById("overall-status");
const backendData = document.getElementById("backend-data");
const lastChecked = document.getElementById("last-checked");
const refreshButton = document.getElementById("refresh-button");

function setBadge(element, isUp) {
  element.textContent = isUp ? "OPERATIONAL" : "UNAVAILABLE";
  element.classList.toggle("up", isUp);
  element.classList.toggle("down", !isUp);
}

async function refreshStatus() {
  refreshButton.disabled = true;
  overallStatus.textContent = "Checking services...";
  setBadge(frontendBadge, true);
  backendData.textContent = "Fetching backend response...";

  try {
    const response = await fetch("/api/backend-status");
    const data = await response.json();
    const backendUp = response.ok && data.status === "UP";
    setBadge(backendBadge, backendUp);
    overallStatus.textContent = backendUp ? "All systems operational" : "Backend needs attention";
    backendData.textContent = JSON.stringify(data, null, 2);
  } catch {
    setBadge(backendBadge, false);
    overallStatus.textContent = "Connection problem";
    backendData.textContent = "Unable to retrieve backend status.";
  } finally {
    lastChecked.textContent = `Last checked: ${new Date().toLocaleString()}`;
    refreshButton.disabled = false;
  }
}

refreshButton.addEventListener("click", refreshStatus);
refreshStatus();
